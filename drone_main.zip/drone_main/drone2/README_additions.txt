# A Risk-Aware Geospatial Drone Routing System

This project models geospatially constrained drone delivery with:
- Routing under no-fly and unsafe (weather) regions
- Segment-tree-backed regional queries (drone density / unsafe coverage)
- JavaFX visualizer for drones density using SegmentTreeService



=== GeoRideDSA Extension ===
- Added pricing/GeoStationaryPriceTracker with SegmentTree-based range queries.
- Integrated SurgeCalculator and FareEngine under menu options 7 and 8 in main.Main.
- VS Code launch configuration added in DSA_PROJECT/.vscode/launch.json.


=== Stage 1 + Stage 3 Extensions ===
- Added ai/ package with SurgePredictor (linear regression), DemandForecaster (moving average), AnomalyDetector (z-score).
- Added services/AStarRouteService (A* pathfinding) and services/SchedulerService (multi-drone assignment).
- Added main/DashboardFX JavaFX analytics dashboard for routes, surge forecasts, and price trends.
