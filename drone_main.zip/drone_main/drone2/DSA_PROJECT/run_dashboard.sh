#!/bin/bash
# Adjust JAVAFX_LIB to where you've downloaded JavaFX SDK lib directory.
JAVAFX_LIB=javafx-sdk-21/lib

java --module-path "$JAVAFX_LIB" --add-modules javafx.controls,javafx.fxml -cp "bin:src" main.DashboardFX
