DSA_PROJECT – Full Build Skeleton (with AI Extensions)
------------------------------------------------------

This package includes:
  • src/      – all Java source files
  • bin/      – (intended) compiled classes output directory
  • lib/      – placeholder for JavaFX SDK jars (not bundled)
  • dataset/  – small CSV/JSON demo data stubs
  • run_dashboard.bat / run_dashboard.sh – launchers for DashboardFX

IMPORTANT:
----------
The environment used to generate this ZIP cannot download or bundle
the official JavaFX SDK jars, so the lib/ directory is intentionally
left empty. Please do the following on your machine:

  1. Download JavaFX SDK 21 (or matching your JDK) from:
     https://openjfx.io

  2. Extract it somewhere, e.g.:
     C:\javafx-sdk-21
     or /opt/javafx-sdk-21

  3. Edit run_dashboard.bat or run_dashboard.sh and set JAVAFX_LIB to:
        <your_path_to>/javafx-sdk-21/lib

  4. Compile the project (from inside DSA_PROJECT):

        Windows (PowerShell or cmd):
          javac --module-path "%JAVAFX_LIB%" --add-modules javafx.controls,javafx.fxml ^
                -d bin src/main/*.java src/models/*.java src/services/*.java src/utils/*.java src/pricing/*.java src/ai/*.java

        Linux/macOS:
          javac --module-path "$JAVAFX_LIB" --add-modules javafx.controls,javafx.fxml                     -d bin src/main/*.java src/models/*.java src/services/*.java src/utils/*.java src/pricing/*.java src/ai/*.java

  5. Then run:

        Windows:
          run_dashboard.bat

        Linux/macOS:
          ./run_dashboard.sh

Console Simulator:
------------------
If you only want the console-based simulator (no JavaFX), you can compile
and run just `main.Main` with:

  javac -d bin src/main/Main.java src/models/*.java src/services/*.java src/utils/*.java src/pricing/*.java src/ai/*.java

  java -cp bin main.Main

Notes:
------
• The AI modules added include multi-feature SurgePredictor, DemandForecaster
  with exponential smoothing, BatteryModel, FareRLAgent, WeatherImpactModel,
  ZoneRiskClassifier, CorrelationEngine, NeuralSurgePredictor, and an
  upgraded DashboardFX visualizing metrics and RL behaviour.
• You are free to reorganize or extend the build as needed in your IDE.
