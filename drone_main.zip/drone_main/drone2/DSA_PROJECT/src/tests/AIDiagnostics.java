package tests;

import ai.BatteryModel;
import ai.CorrelationEngine;
import ai.DemandForecaster;
import ai.FareRLAgent;
import ai.SurgePredictor;

public class AIDiagnostics {

    public static void run() {
        System.out.println("\n=====================");
        System.out.println(" AI DIAGNOSTIC REPORT ");
        System.out.println("=====================");

        try {
            runSurgePredictorTest();
            runDemandForecasterTest();
            runBatteryModelTest();
            runRLAgentTest();
            runCorrelationTest();
            System.out.println("\n✅ AI metrics generated successfully!\n");
        } catch (Exception e) {
            System.out.println("❌ Error in AI Diagnostics: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void runSurgePredictorTest() {
        SurgePredictor sp = new SurgePredictor();
        double[][] X = {
                {8, 0.2, 35, 15},   // timeIndex, weatherIndex, demand, driverCount
                {10, 0.3, 45, 20},
                {18, 0.8, 90, 12},
                {20, 0.1, 30, 25}
        };
        double[] y = {1.2, 1.6, 2.8, 1.1}; // example surge labels
        sp.train(X, y);
        System.out.printf("[SurgePredictor] RMSE = %.3f  MAE = %.3f  R² = %.3f%n",
                sp.getRmse(), sp.getMae(), sp.getR2());
    }

    private static void runDemandForecasterTest() {
        DemandForecaster df = new DemandForecaster();
        double[] t = {0, 1, 2, 3, 4, 5, 6, 7};
        double[] demand = {45, 48, 52, 55, 60, 62, 64, 67};
        df.train(t, demand);
        System.out.printf("[DemandForecaster] RMSE = %.3f  MAE = %.3f  Forecast(Next) = %.1f%n",
                df.getRmse(), df.getMae(), df.forecastNext(1)[0]);
    }

    private static void runBatteryModelTest() {
        BatteryModel bm = new BatteryModel();
        double[] dist = {5, 10, 15, 20};
        double[] energy = {8, 14, 21, 27};
        bm.train(dist, energy);
        double predicted = bm.predict(15.0, 120.0);
        System.out.printf("[BatteryModel] Predicted energy drain for 15km,120m = %.2f%%%n", predicted);
    }

    private static void runRLAgentTest() {
        FareRLAgent rl = new FareRLAgent(1, 4); // 1 zone, 4 surge buckets
        int zone = 0;
        double surge = 1.0;
        for (int episode = 0; episode < 30; episode++) {
            int action = rl.chooseAction(zone, surge, 0.2); // epsilon-greedy
            // simple shaped reward: prefer surge ~1.5
            double reward = -Math.abs(surge - 1.5);
            double nextSurge = surge + 0.1 * (Math.random() - 0.5);
            rl.update(zone, surge, action, reward, nextSurge);
            surge = nextSurge;
        }
        System.out.println("[FareRLAgent] Ran 30 simulated episodes (Q-table updated).");
    }

    private static void runCorrelationTest() {
        CorrelationEngine ce = new CorrelationEngine();
        double[] demand = {40, 50, 60, 80, 100};
        double[] supply = {60, 55, 50, 40, 30};
        double r = CorrelationEngine.pearson(demand, supply);
        System.out.printf("[CorrelationEngine] Demand–Supply correlation = %.3f%n", r);
    }
}
